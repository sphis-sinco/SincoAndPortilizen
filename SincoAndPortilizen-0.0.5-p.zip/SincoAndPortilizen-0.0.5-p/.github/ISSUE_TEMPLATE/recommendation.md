---
name: Recommendation
about: Recommend any idea you have for the game
title: "[RECOMMENDATION] "
labels: 'Priority: Low, Response: Unknown, Status: Recommendation'
assignees: ''

---

# What do you recommend?

# Why?
