---
name: Question
about: Ask a question about the game
title: "[QUESTION] "
labels: 'Priority: Low, Response: Unknown, Status: Question'
assignees: ''

---

# What is your question?

# What brought this up?
